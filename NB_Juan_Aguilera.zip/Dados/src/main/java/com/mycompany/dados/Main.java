
package com.mycompany.dados;
import Datos.Dado;
import Datos.Datos;
public class Main {
    public static void main(String[] args){
        Dado.Menu();
    }
}
